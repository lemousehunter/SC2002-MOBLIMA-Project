package Enum;

public enum cineplexTypeEN {
	yearRound,
	seasonal,
	closed
}