package Entity;

import Enum.UserTypeEN;
import java.util.UUID;

/**
 * A User Object
 * 
 * <p>
 * A <code>User</code> object contains all the parameters
 * used to store user information
 * </p>
 * 
 */

public class UserEY {

	/**
	 * The type of user (MovieGoer or Staff)
	 */
	private UserTypeEN userType;
	/**
	 * The username
	 */
	private String userName;
	/**
	 * The user ID
	 */
	private String userID;

	
	/**
	 * Constructor for User object
	 * @param userType type of user (Moviegoer or staff)
	 * @param userName user name of the user
	 */
	public UserEY(UserTypeEN userType, String userName) {
		this.userID = UUID.randomUUID().toString();
		this.userType = userType;
		this.userName = userName;
	}
	/**
	 * Constructor for User object
	 * @param userID user ID of the user
	 * @param userType type of user (Moviegoer or staff)
	 * @param userName	user name of the user
	 */
	public UserEY(String userID, UserTypeEN userType, String userName) {
		if (userID.equals("")) {
			this.userID = UUID.randomUUID().toString();
		} else {
			this.userID = userID;
		}
		this.userType = userType;
		this.userName = userName;

	}
	
	/** 
	 * Method to get the user ID
	 * @return The UserID
	 */
	public String getUserID() {
		return userID;
	}

	
	/** 
	 * Method to set the User ID
	 * @param userID The new UserID
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	
	/** 
	 * Method to get user type
	 * @return the type of user (MovieGoer or Staff)
	 */
	public UserTypeEN getUserType() {
		return userType;
	}

	
	/** 
	 * Method to set user type
	 * @param userType The new type of user (MovieGoer or Staff)
	 */
	public void setUserType(UserTypeEN userType) {
		this.userType = userType;
	}

	
	/** 
	 * Method to get user name
	 * @return the username
	 */
	public String getUserName() {
		return userName;
	}

	
	/** 
	 * Method to set user name	
	 * @param userName the new username
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

}