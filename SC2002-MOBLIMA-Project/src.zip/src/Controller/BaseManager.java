package Controller;
import App.Base;

/**
 * A base manager interface
 *
 */
public interface BaseManager extends Base {
   
    /**
     * Method to set Master List
     */
    public void setMasterLists();
}
