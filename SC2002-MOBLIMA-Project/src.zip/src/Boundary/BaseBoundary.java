package Boundary;
import App.Base;

/**
 * A BaseBoundary interface
 *
 */
public interface BaseBoundary extends Base {

    /**
     * Method to set boundaries
     */
    public void setBoundaries();

}
